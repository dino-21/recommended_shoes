import React from "react";

const Footer = () => {
  let foo = {
    color: "#fff",
    backgroundColor: "#000",
    padding: "20px 0px",
    marginTop: "80px",
    textAlign:'center'
  };
  return (
    <>
      <p style={foo}>COPYRIGHT(C) 2024 TrendStep, Inc. All Rights Reserved</p>
    </>
  );
};

export default Footer;
